# Grandmothers voice by Kayock 2.1

**An offline Family Legacy Studio.** Drop in a GEDCOM `.ged` file exported
from Ancestry (or FamilySearch, RootsMagic, Gramps, MyHeritage…), add your
photo and document folders, and build a standalone interactive Family Story
Explorer, media galleries, printable keepsake booklets, and Markdown
research vaults — all on your own computer, with the original GED file
never modified.

> **Turn a family tree into something people can actually walk through.**

- 100% free and open source under the **MIT license** — no paid tiers, no
  subscriptions, no ads, no accounts, no telemetry, no cloud, no feature
  restrictions.
- **Fully functional offline** after extraction, including opening by
  double-click (`file://`) with no server.
- **Read-only import**: your GED file is never edited or overwritten.
  Corrections and memories are exported as reviewable reports instead.
- One self-contained HTML application file — no installation, no build step.

---

## What it creates from one GED file

| Output | What it is |
| --- | --- |
| **Interactive HTML explorer** | A standalone file your family opens in any browser: search, person pages, an interactive family tree diagram, a timeline, a places/migration view, photo & document galleries, and Tree Refinement Mode for collecting memories and corrections. |
| **HTML + media ZIP** | The same explorer packaged with the actual photo/document files for bigger collections. |
| **Obsidian vault ZIP** | One Markdown page per person with YAML frontmatter, wiki links, index pages (People A–Z, Surnames, Places, Timeline, Sources, Research Questions) and the media files with working embed links. |
| **Logseq vault ZIP** | Outliner-friendly pages (`pages/`) with page references and `assets/` media. |
| **One Markdown file** | The whole parsed tree in readable Markdown. |
| **Parsed JSON** | The full model (people, families, events, citations, media, diagnostics) for tools and scripts. |
| **Diagnostics & source-quality reports** | Data issues, missing references, date conflicts, citation coverage, and the people whose events lack evidence. |
| **Refinement backups & suggested-changes report** | Versioned JSON backups from every relative, merged with conflict review, plus a structured hand-off list for your genealogy software. |
| **Family Story Booklet** | A printable keepsake (individual, branch, or surname) with biography, chronology, photographs, family memories with attribution, sources, and open research questions. |

## Quick start

1. Download / unzip this folder.
2. Double-click **`Grandmothers_Voice_by_Kayock.html`** (or use a launcher — see
   INSTALL.md).
3. Click **Load Sample Family** to try everything without your own data, or
   **choose your `.ged`** file and click **Parse GED**.
4. Check the **Diagnostics** tab, then build whichever outputs you want.

The guided introduction on first launch walks through the whole studio.

## Two themes

- **Dark · Kayock Purple** — the original deep-purple night look.
- **Light · Southwest Heritage** — a warm, sun-baked palette inspired by
  the American Southwest landscape: Desert Sand backgrounds, Warm Ivory
  cards, Deep Mesa Brown text, Southwestern Turquoise interactive accents,
  Adobe Clay and Terracotta highlights, Sunlit Ochre selected details and
  Sage Green support. Designed respectfully — regional color identity only,
  no sacred or tribal imagery. Both themes share the same features, meet
  WCAG AA contrast, respect reduced-motion settings, and persist per app
  (builder and explorer remember your choice separately).

## Recommended family workflow

1. Export the GED from Ancestry (or any genealogy program).
2. Run it through Grandmothers voice by Kayock and generate the explorer.
3. Share the explorer (with a privacy mode applied if any recipients should
   not see living people's details).
4. Relatives open it, walk through the family, and record memories,
   corrections, duplicate suspicions and photo requests in **Tree
   Refinement Mode** — notes autosave quietly in their browser.
5. Each relative exports a **JSON refinement backup** and sends it back.
6. You import every backup in the **Refine** tab, review conflicts
   (keep current / use imported / keep both, with attribution), flag
   duplicate suggestions, and export one merged backup plus a structured
   **suggested GEDCOM changes** report.
7. Review that report in your genealogy software — the tool never edits the
   official tree itself.
8. Print a **Family Story Booklet** for a reunion, birthday or memorial.

## Privacy

- No network access, ever. See **PRIVACY.md** for the full statement.
- Before sharing, pick a privacy mode: **redact** living people (hide
  dates/places/notes/sources/media), **redact names** (initials), or
  **exclude** them (placeholder people keep the structure readable).
  The "possibly living" threshold is configurable.
- The **Family sharing edition** export profile makes smaller files:
  source transcripts trimmed, photos downscaled, audio/video not embedded.
- The original GED is opened read-only; automated tests verify it stays
  byte-for-byte identical.

## Data fidelity

- GEDCOM **5.5.1 and 7.0** are detected and reported.
- Encodings are detected (UTF-8/16 BOM, `1 CHAR` declarations, ANSEL,
  Windows-1252 with UTF-8 validation and fallback) and reported.
- Notes (person, family, event-level, shared `@N..@` records), source
  citations (`PAGE`, `QUAY` evidence quality, `DATA.TEXT`), and media
  references — including multi-file GEDCOM 7 `OBJE` records — are
  preserved. Nothing is silently discarded; unsupported structures are
  counted and reported.
- Uncertain dates (`ABT 1850`, `BET 1920 AND 1925`, `FROM 1901 TO 1903`,
  `1893/94`, phrase dates) are preserved exactly — never converted to
  precise dates.
- The **Diagnostics tab** lists unresolved references, duplicate ids,
  malformed lines, relationship conflicts and date problems; the
  **source-quality report** shows where evidence is missing without ever
  inventing facts.

## Testing

```
node tests/run_tests.mjs             # automated tests (should end: ALL TESTS PASSED)
node tests/run_tests.mjs --perf      # adds the 10k-person performance benchmark
node tests/fixtures/make_fixtures.js # regenerate the synthetic GEDCOM fixtures
```

The suite loads the DOM-free core functions from the shipped HTML and runs
them verbatim against synthetic fixtures (5.5.1, ANSEL, Windows-1252, GEDCOM
7, malformed files, duplicate xrefs, 10,000 people). See
`tests/README.md` and CONTRIBUTING.md.

## Performance

Measured on a synthetic tree of **10,000 people / 3,340 families** (Node 24,
2026 hardware baseline):

| Stage | Time |
| --- | --- |
| Tokenize 123k GED lines | ~85 ms |
| Full parse to model | ~400 ms |
| Duplicate suggestions | ~0.7 s |
| Explorer HTML generation | ~70 ms (≈13 MB single file) |

The explorer renders in bounded slices (search, timeline, places, tree), so
large trees stay responsive; media embedding is streamed with progress and
cancellation.

## Project files

```
Grandmothers_Voice_by_Kayock.html          the application (single self-contained file)
RUN_GED_LEGACY_BUILDER.bat       Windows launcher
RUN_GED_LEGACY_BUILDER.sh        Linux / macOS launcher
RUN_GED_LEGACY_BUILDER.command   macOS double-click launcher
README.md                        this file
INSTALL.md                       platform-by-platform installation
Kayock_Legacy_Builder_User_Guide.md / .html   full user guide
CHANGELOG.md                     version history
CONTRIBUTING.md                  how to contribute
PRIVACY.md                       privacy statement
THIRD_PARTY_NOTICES.md           technology notices
LICENSE                          MIT
foxai_module_manifest.json       module manifest (Legacy Studio)
samples/                         synthetic sample family + sample media
tests/                           automated tests + fixtures
```

## Limitations (honest list)

- Ancestry ZIP downloads must be unzipped first — choose the `.ged` inside.
- ANSEL decoding covers the common diacritics; rare ANSEL symbols fall back
  to close Latin equivalents with a warning (the count is reported).
- The migration view lists recorded places in chronological order; it does
  not invent map coordinates.
- Living-person detection is a date heuristic — always double-check a
  sharing export.
- The single-file explorer embeds media as base64; for very large media
  collections (tens of MB+) use the HTML + media ZIP export instead.
- 5.5.1 `BLOB` inline binary media is flagged and referenced, not embedded.
- Very large trees produce very large single-file explorers (≈13 MB for
  10k people); that is normal.

## License

MIT — see LICENSE. Copyright (c) 2026 Grandmothers voice by Kayock project
contributors. Free forever: no paid tiers, no ads, no accounts, no feature
restrictions.
